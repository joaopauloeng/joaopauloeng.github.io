$('.rslides').responsiveSlides({
    auto: false,             
    speed: 500,           
    timeout: 500,       
});

$(function() {
    $(".rslides").responsiveSlides();
});